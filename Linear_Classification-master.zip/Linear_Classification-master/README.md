# Linear_Classification
Linear Classification demo using keras
